import json
import boto3
from decimal import Decimal

bedrock = boto3.client('bedrock-runtime', region_name='us-east-1')
dynamodb = boto3.resource('dynamodb')
cache_table = dynamodb.Table('mrktdly-ticker-cache')

def decimal_to_float(obj):
    if isinstance(obj, Decimal):
        return float(obj)
    raise TypeError

def lambda_handler(event, context):
    """Generate AI analysis for a ticker (async endpoint)"""
    
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET,OPTIONS',
        'Content-Type': 'application/json'
    }
    
    if event.get('httpMethod') == 'OPTIONS':
        return {'statusCode': 200, 'headers': headers, 'body': ''}
    
    try:
        ticker = event.get('queryStringParameters', {}).get('ticker', '').upper().strip()
        
        if not ticker:
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({'error': 'Ticker required'})
            }
        
        # Check if we have cached ticker data
        cached = cache_table.get_item(Key={'ticker': ticker})
        if 'Item' not in cached:
            return {
                'statusCode': 404,
                'headers': headers,
                'body': json.dumps({'error': 'Ticker data not found. Analyze ticker first.'})
            }
        
        ticker_data = cached['Item'].get('data')
        comprehensive = cached['Item'].get('comprehensive')
        
        # Generate AI analysis
        analysis = generate_ticker_analysis(ticker, ticker_data, comprehensive)
        
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({'analysis': analysis}, default=decimal_to_float)
        }
        
    except Exception as e:
        print(f'Error: {e}')
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({'error': str(e)})
        }

def generate_ticker_analysis(ticker, ticker_data, comprehensive):
    """Generate AI analysis using Claude"""
    
    prompt = f"""Analyze {ticker} based on this data:

Price: ${ticker_data.get('price')}
Change: {ticker_data.get('change_percent')}%
Volume: {ticker_data.get('volume'):,}
52W Range: ${ticker_data.get('low_52w')} - ${ticker_data.get('high_52w')}

Technical Indicators:
- RSI: {ticker_data.get('rsi', 'N/A')}
- MACD: {ticker_data.get('macd', 'N/A')}
- Trend: {ticker_data.get('trend', {}).get('direction', 'N/A')}

Provide concise analysis in JSON format:
{{
  "price_action": "brief summary",
  "technical_analysis": ["point 1", "point 2"],
  "key_levels": [{{"level": "$X", "note": "support/resistance"}}],
  "trading_considerations": ["consideration 1"],
  "risk_assessment": ["risk 1"]
}}"""

    try:
        response = bedrock.invoke_model(
            modelId='anthropic.claude-3-haiku-20240307-v1:0',
            body=json.dumps({
                'anthropic_version': 'bedrock-2023-05-31',
                'max_tokens': 2500,
                'messages': [{
                    'role': 'user',
                    'content': prompt
                }]
            })
        )
        
        result = json.loads(response['body'].read())
        analysis_text = result['content'][0]['text']
        
        # Extract JSON
        start = analysis_text.find('{')
        end = analysis_text.rfind('}') + 1
        if start != -1 and end > 0:
            return json.loads(analysis_text[start:end])
        
        return {'error': 'Failed to parse AI response'}
        
    except Exception as e:
        print(f'Bedrock error: {e}')
        return {'error': str(e)}
